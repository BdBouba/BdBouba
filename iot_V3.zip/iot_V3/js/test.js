document.addEventListener('DOMContentLoaded', function() {

    const modeautomatiqueLink = document.getElementById('modeautomatiqueLink');
    const allumerClim = document.getElementById('allumerClimatisation');
    const eteindreClim = document.getElementById('eteindreClimatisation');
    const allumerRadia = document.getElementById('allumerRadiation');
    const eteindreRadia = document.getElementById('eteindreRadiation');



    modeautomatiqueLink.addEventListener('click', function() {
        controlCLM('https://api.thingspeak.com/update?api_key=RBKTPDR3UJR7A7N5&field1=0', 'Le mode automatique est activer avec succès.');
        
    });
    allumerClim.addEventListener('click', function() {
        controlCLM('https://api.thingspeak.com/update?api_key=XDV5YWDLQG89Y4VB&field1=1', 'Climatisation allumée avec succès.');
    });

    eteindreClim.addEventListener('click', function() {
        controlCLM('https://api.thingspeak.com/update?api_key=XDV5YWDLQG89Y4VB&field1=0', 'Climatisation éteinte avec succès.');

    });

    allumerRadia.addEventListener('click', function() {
        controlCLM('https://api.thingspeak.com/update?api_key=ZWXF8DJ9XYHDN3C3&field1=1', 'Chauffage allumé avec succès.');

    });

    eteindreRadia.addEventListener('click', function() {
        controlCLM('https://api.thingspeak.com/update?api_key=ZWXF8DJ9XYHDN3C3&field1=0', 'Chauffage éteint avec succès.');

    });

    function controlCLM(url, successMessage) {
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erreur réseau !');
                }
                showMessage(successMessage);
                return response.json();
            })
            .then(data => {
                console.log('Réponse API:', data);
            })
            .catch(error => {
                console.error('Erreur lors de la requête :', error);
            });
    }

    function showMessage(message) {
        // Afficher le message dans la div message
        messageDiv.textContent = message;

        // Effacer le message après 3 secondes
        setTimeout(function() {
                messageDiv.textContent = '';
            }, 3000);
    }
});