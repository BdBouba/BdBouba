document.addEventListener('DOMContentLoaded', function() {
    const allumerVerteBtn = document.getElementById('allumerVerte');
    const eteindreVerteBtn = document.getElementById('eteindreVerte');
    const allumerRougeBtn = document.getElementById('allumerRouge');
    const eteindreRougeBtn = document.getElementById('eteindreRouge');
    const modemanuelBtn = document.getElementById('modemanuel');
    const modeautomatiqueBtn = document.getElementById('modeautomatique');
    const eteindreToutesBtn = document.getElementById('eteindreToutes');
    const messageDiv = document.getElementById('message');

    allumerVerteBtn.addEventListener('click', function() {
        controlLED('https://api.thingspeak.com/update?api_key=XDV5YWDLQG89Y4VB&field1=1', 'LED Verte allumée avec succès.');
    });

    eteindreVerteBtn.addEventListener('click', function() {
        controlLED('https://api.thingspeak.com/update?api_key=XDV5YWDLQG89Y4VB&field1=0', 'LED Verte éteinte avec succès.');
    });

    allumerRougeBtn.addEventListener('click', function() {
        controlLED('https://api.thingspeak.com/update?api_key=ZWXF8DJ9XYHDN3C3&field1=1', 'LED Rouge allumée avec succès.');
    });

    eteindreRougeBtn.addEventListener('click', function() {
        controlLED('https://api.thingspeak.com/update?api_key=ZWXF8DJ9XYHDN3C3&field1=0', 'LED Rouge éteinte avec succès.');
    });

    modemanuelBtn.addEventListener('click', function() {
        controlLED('https://api.thingspeak.com/update?api_key=RBKTPDR3UJR7A7N5&field1=1', 'Le mode manuel est activer avec succès.');
        controlLED('https://api.thingspeak.com/update?api_key=ZWXF8DJ9XYHDN3C3&field1=0', '');
        controlLED('https://api.thingspeak.com/update?api_key=XDV5YWDLQG89Y4VB&field1=0', '');
    });

    modeautomatiqueBtn.addEventListener('click', function() {
        controlLED('https://api.thingspeak.com/update?api_key=RBKTPDR3UJR7A7N5&field1=0', 'Le mode automatique est activer avec succès.');
    });

      eteindreToutesBtn.addEventListener('click', function() {
      controlLED('https://api.thingspeak.com/update?api_key=XDV5YWDLQG89Y4VB&field1=0', 'Toutes les LEDs éteintes avec succès.');
      controlLED('https://api.thingspeak.com/update?api_key=ZWXF8DJ9XYHDN3C3&field1=0', '');
    });

    function controlLED(url, successMessage) {
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erreur réseau !');
                }
                showMessage(successMessage);
                return response.json();
            })
            .then(data => {
                console.log('Réponse API:', data);
            })
            .catch(error => {
                console.error('Erreur lors de la requête :', error);
            });
    }

    function showMessage(message) {
        // Afficher le message dans la div message
        messageDiv.textContent = message;

        // Effacer le message après 3 secondes
      /*  setTimeout(function() {
            messageDiv.textContent = '';
        }, 3000);
        */
    }
});
