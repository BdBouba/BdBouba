<?php
// Récupérer les données depuis ThingSpeak
$url = "https://api.thingspeak.com/channels/2420195/feeds.json?api_key=G4NY1AZNIAV4DTEG&results=1";

// Effectuer une requête HTTP GET
$data = file_get_contents($url);

// Convertir les données JSON en tableau associatif
$data_array = json_decode($data, true);

// Récupérer la dernière température
$temperature = $data_array['feeds'][0]['field1'];

// Déterminer quelle image afficher en fonction de la température
if ($temperature >= 25) {
    $imageName = "./images/ventilateurOnn.webp";
} else {
    $imageName = "./images/www.animated-gifs.eu-703372.gif";
}

// Renvoyer le texte de la température et le chemin de l'image séparés par un pipe "|"
echo "Dernière température : " . $temperature . " C" . "|" . $imageName;
?>
